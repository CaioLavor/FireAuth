package br.unimes.appfireauth

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import br.unimes.appfireauth.databinding.ActivityMainBinding
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth


class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        auth = Firebase.auth

        binding.btnLogin.setOnClickListener{
            if (binding.edtEmail.text.toString().isNotEmpty() && binding.edtPassword.text.toString().isNotEmpty()) {
                val email = binding.edtEmail.text.toString()
                val password = binding.edtPassword.text.toString()
                auth.signInWithEmailAndPassword(email, password)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Carregando", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this, SegundaActivity::class.java)
                        startActivity(intent)
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Erro!", Toast.LENGTH_SHORT).show()
                    }
            } else {
                Toast.makeText(this, "Algum espaço está em branco!", Toast.LENGTH_SHORT).show()
            }
        }
        binding.btnReg.setOnClickListener {
            if (binding.edtEmail.text.toString().isNotEmpty() && binding.edtPassword.text.toString().isNotEmpty()) {
                val email = binding.edtEmail.text.toString()
                val password = binding.edtPassword.text.toString()
                auth.createUserWithEmailAndPassword(email, password)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Criado com Sucesso", Toast.LENGTH_SHORT).show()
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Erro", Toast.LENGTH_SHORT).show()
                    }
            } else{
                Toast.makeText(this, "Algum espaço está em branco!", Toast.LENGTH_SHORT).show()}
        }
        binding.btnRed.setOnClickListener {

            if(binding.edtEmail.text.toString().isNotEmpty()) {
                val email = binding.edtEmail.text.toString()
                Firebase.auth.sendPasswordResetEmail(email)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Email Enviado", Toast.LENGTH_SHORT).show()
                    }

            } else {
                Toast.makeText(this, "Email em branco", Toast.LENGTH_SHORT).show()
            }


                }
        }
    }